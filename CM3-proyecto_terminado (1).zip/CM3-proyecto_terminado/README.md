# CM3
Ejercicio de consolidación de modulo BootCamp Talento Digital

El código utiliza HTML, CSS, JavaScript (con jQuery) y la biblioteca de iconos Font Awesome.

Es una aplicación sencilla de presupuesto. descripcion de su funcionalidad:

Al cargar la página, se inicializan tres variables importantes: presupuesto, gasto y saldo.

El usuario tiene la posibilidad de ingresar un presupuesto en el formulario correspondiente al hacer clic en el botón "Agregar Presupuesto". 
El valor del presupuesto ingresado se muestra en una tabla dedicada al presupuesto.

Además, el usuario puede agregar gastos proporcionando un nombre y su respectiva cantidad en el formulario correspondiente. 
Al hacer clic en el botón "Agregar Gasto", el gasto se añade a una lista y se recalcula automáticamente el saldo disponible.

Los gastos agregados se presentan en una tabla de gastos ubicada debajo del formulario. 
Cada gasto cuenta con un botón de eliminación para permitir al usuario eliminar gastos seleccionados. 
Al eliminar un gasto, el saldo disponible se recalcula automáticamente.

El saldo disponible se muestra en la tabla de presupuesto, y se actualiza dinámicamente cada vez que se agrega o elimina un gasto.

En resumen, esta aplicación permite al usuario establecer un presupuesto y luego administrar los gastos asociados. 
Proporciona una visualización clara del presupuesto, los gastos y el saldo disponible. 

Además, se brinda la opción de eliminar gastos si es necesario.
